#include "Camera.h"

Camera::Camera(float w, float h, GLint *shaderVars) {
    eye = vec3(0.0f, EYE_HEIGHT, 4.0f);
    lookAtPoint = lookAt = vec3(0.0f, EYE_HEIGHT, 1.0f);
    up = vec3(0.0f, 1.0f, 0.0f);
    step = 0.2;
    width = w;
    height = h;
    pitch = deg2rad(0.0);
    yaw = deg2rad(270.0);
    calculateBasisVectors();
    fly = 0;
    health = MAX_PLAYER_HEALTH;
    blood = vec3(0.0, .2, .2);
    
    object = new Object( vec3(eye.x, eye.y, eye.z), vec3(-1, -1, -1), vec3(1, 1, 1), vec3(0.2, 0.2, 0.2),
     GeometryCreator::CreateCylinder(0.0f, 0.0f, 0.0f, 32, 16), shaderVars);
    object->rotationAngle = yaw;
    object->rotationAxis = vec3(0, 1, 0);
}

Camera::Camera(vec3 eye, vec3 lookAt, vec3 up, float step, float w, float h, GLint *shaderVars) {
    this->eye = eye;
    this->lookAtPoint = this->lookAt = lookAt;
    this->up = up;
    this->step = step;
    width = w;
    height = h;
    pitch = deg2rad(0.0);
    yaw = deg2rad(90.0);
    calculateBasisVectors();
    fly = 0;
    health = MAX_PLAYER_HEALTH;
    blood = vec3(0.0, .2, .2);
    
    object = new Object(vec3(eye.x, eye.y, eye.z), vec3(-1, -1, -1), vec3(1, 1, 1), vec3(0.2, 0.2, 0.2),
     GeometryCreator::CreateCylinder(0.0f, 0.0f, 0.0f, 32, 16), shaderVars);
    object->rotationAngle = yaw;
    object->rotationAxis = vec3(0, 1, 0);
}

void Camera::updateObject(vec3 direction) {
    eye.x += (step * direction.x);
    //eye.y += (step * direction.y);
    eye.z += (step * direction.z);

    lookAt.x += (step * direction.x);
    //lookAt.y += (step * direction.y);
    lookAt.z += (step * direction.z);
}

void Camera::calculateBasisVectors() {
    vec3 gaze = eye - lookAt;
    
    w = normalize(gaze);

    vec3 cros = cross(up, w);
    
    u = normalize(cros);
    v = normalize(cross(w, u));
}

void Camera::mouseMove() {
    float changeX = prev.x - cur.x;
    float changeY = prev.y - cur.y;

    //cout << "changeX: " << changeX << endl;
    //cout << "changeY: " << changeY << endl;

    pitch += deg2rad(height * (changeY / HEIGHT_DEG));
    yaw += deg2rad(width * (changeX / WIDTH_DEG));
    if (pitch > HEIGHT_LIMIT) {
       pitch = HEIGHT_LIMIT;
    }
    if (pitch < -HEIGHT_LIMIT) {
       pitch = -HEIGHT_LIMIT;
    }

    //cout << "pitch: " << pitch << endl;
    //cout << "yaw: " << yaw << endl;

    float radius = sqrt((eye.x - lookAtPoint.x) * (eye.x - lookAtPoint.x) + 
        (eye.y - lookAtPoint.y) * (eye.y - lookAtPoint.y) + (eye.z - lookAtPoint.z) * (eye.z - lookAtPoint.z));
        
    lookAt.x = -radius * cos(pitch) * cos(yaw) + eye.x;
    lookAt.y = radius * sin(pitch) + eye.y;
    lookAt.z = radius * cos(pitch) * cos(deg2rad(90.0) - yaw) + eye.z;

    calculateBasisVectors();
    //printVectors();
}

float Camera::deg2rad(float degrees) {
    return degrees * (M_PI/180);
}

void Camera::groundEyes() {
    lookAt.y = EYE_HEIGHT + (lookAt.y - eye.y);
    eye.y = EYE_HEIGHT;
}


void Camera::moveToward(vec3 direction, list<Object> * buildings) {
    vec3 oldPosition = object->position;
    object->position.x += (step * direction.x);
    //object->position.y += (step * direction.y);
    object->position.z += (step * direction.z);
    vec3 dir;
    list<Object> b = object->Object::hitsBuilding(buildings);
    for(list<Object>::iterator it = b.begin(); it != b.end(); it++) {
        dir = object->Object::checkPaths(*it);
        if (dir.x == 0) {
           if (dir.y < 0 && direction.x > 0) {
              direction.x = 0;
           }
           if (dir.y > 0 && direction.x < 0) {
              direction.x = 0;
           }
        } else {
           if (dir.y < 0 && direction.z > 0) {
              direction.z = 0;
           }
           if (dir.y > 0 && direction.z < 0) {
              direction.z = 0;
           }
        }
    }
    object->position = oldPosition;
    object->position.x += (step * direction.x);
    //object->position.y += (step * direction.y);
    object->position.z += (step * direction.z);
    updateObject(direction);
}


void Camera::moveForward(list<Object> * buildings) {
    /*eye.x -= (step * w.x);
    eye.y -= (step * w.y);
    eye.z -= (step * w.z);
    

    lookAt.x -= (step * w.x);
    lookAt.y -= (step * w.y);
    lookAt.z -= (step * w.z);*/
    
    moveToward(-w, buildings);
    //printVectors();
    if (!fly) {
       groundEyes();
    }
}

void Camera::moveBack(list<Object> * buildings) {
/*    eye.x += step * w.x;
    eye.y += step * w.y;
    eye.z += step * w.z;

    lookAt.x += step * w.x;
    lookAt.y += step * w.y;
    lookAt.z += step * w.z;*/
    moveToward(w, buildings);
    //printVectors();
    if (!fly) {
       groundEyes();
    }
}

void Camera::moveLeft(list<Object> * buildings) {
/*    eye.x -= step * u.x;
    eye.y -= step * u.y;
    eye.z -= step * u.z;

    lookAt.x -= step * u.x;
    lookAt.y -= step * u.y;
    lookAt.z -= step * u.z;*/
    moveToward(-u, buildings);
    //printVectors();
    if (!fly) {
       groundEyes();
    }
}

void Camera::moveRight(list<Object> * buildings) {
    /*eye.x += step * u.x;
    eye.y += step * u.y;
    eye.z += step * u.z;

    lookAt.x += step * u.x;
    lookAt.y += step * u.y;
    lookAt.z += step * u.z;*/
    moveToward(u, buildings);
    //printVectors();
    if (!fly) {
       groundEyes();
    }
}

void Camera::screen(float w, float h) {
    width = w;
    height = h;
}

void Camera::bleed() {
    float b = health/100.0;
    blood.r = 1 - b;
    //blood.g = b;
    //blood.b = b;
}

void Camera::heal() {
    float b = health/100.0;
    blood.r = 1 - b;
    //blood.g = b;
    //blood.b = b;
}

void Camera::printVectors() {
    cout << "eye: " << eye.x << ", " << eye.y << ", " << eye.z << endl;
    cout << "lookAt: " << lookAt.x << ", " << lookAt.y << ", " << lookAt.z << endl;
    cout << "up: " << up.x << ", " << up.y << ", " << up.z << endl;

    cout << "u: " << u.x << ", " << u.y << ", " << u.z << endl;
    cout << "v: " << v.x << ", " << v.y << ", " << v.z << endl;
    cout << "w: " << w.x << ", " << w.y << ", " << w.z << endl;
}

void Camera::printMouseMovement() {
    cout << "cur: " << cur.x << ", " << cur.y << endl;
    cout << "prev: " << prev.x << ", " << prev.y << endl;
}
