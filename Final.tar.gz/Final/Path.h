#ifndef __PATH__
#define __PATH__

#include "resources.h"
#include "Object.h"

#define STREET 0
#define INTERSECTION 1
#define SIDEWALK 2

using namespace std;
using namespace glm;

class Path : public Object {
    private:
        int tiles;
    private:
        void createStreet();
        void createIntersection();
        void createSidewalk();

    public:
        Path(vec3 position, int type, int tiles, float angle, GLint *shaderVars);

};

#endif
