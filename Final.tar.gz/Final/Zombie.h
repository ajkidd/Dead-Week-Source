#ifndef __ZOMBIE__
#define __ZOMBIE__

#include "resources.h"
#include "Object.h"
#include "Building.h"
#include "Camera.h"

#define ZOMBIE_DAMAGE 5.0
#define ZOMBIE_ATTACK_COOLDOWN 20
#define ZOMBIE_REACH 3
#define MAX_HEALTH 15.0
#define ZOMBIE_SPEED .07
#define ROTATE_AMOUNT 1
#define BUILDING_BUFFER 0

using namespace std;
using namespace glm;

class Zombie : public Object {
    public:
        float speed;
        float health;
        bool move;
        bool atk;

    private:
        int leftArm, rightArm;
        int leftThigh, rightThigh;
        int leftLeg, rightLeg;
        int leftLegBone, rightLegBone;
        int leftFoot, rightFoot;
        float leftLegRot, rightLegRot;
        float leftArmRot, rightArmRot;
        int cooldown;

    public:
        Zombie(vec3 position, vec3 color, Mesh *mesh, GLint *shaderVars);
        void moveToward(vec3 destination, list<Object> * buildings);
        void onHit(float damage);
        void animateWalk();
        void lookTowards(vec3 camera);
        bool isMoving(vec3 camera);
        bool attack(Camera *c);

    private:
        void buildZombie();
        Object get(int index);
        Object get(Object l, int index);
        void update(int index, Object o);
        void update(Object l, int index, Object o);
};

#endif
