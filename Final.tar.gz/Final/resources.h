#ifndef _RESOURCES_H_
#define _RESOURCES_H_

#ifdef __APPLE__
#include "GLUT/glut.h"
#include <OPENGL/gl.h>
#endif
#ifdef __unix__
#include <GL/glut.h>
#endif
#ifdef _WIN32
#include <GL\glew.h>
#include <GL\glut.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <list>
#include <string>
#include <iostream>
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp" //perspective, trans etc
#include "glm/gtc/type_ptr.hpp" //value_ptr
#include "GLSL_helper.h"
#include "MStackHelp.h"
#include "GeometryCreator.h"

#endif

extern int a_step;
