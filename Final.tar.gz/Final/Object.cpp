#include "Object.h"

Object::Object(vec3 pos, vec3 join, float angle, vec3 axis, vec3 min, vec3 max, vec3 col, Mesh *mesh, GLint *shaderVars) {
   expired = false;
   position = pos;
   joint = join;
   rotationAngle = angle;
   rotationAxis = axis;
   scale = vec3(1);
   collider.minPos = min;
   collider.maxPos = max;
   color = col;
   model = mesh;
   boundingBox = GeometryCreator::CreateCube(max - min);
   h_uModelMatrix = shaderVars[0];
   h_aPosition = shaderVars[1];
   h_aNormal = shaderVars[2];
   h_uColor = shaderVars[3];
   gravity = GRAVITY;
}

Object::Object(vec3 pos, vec3 min, vec3 max, vec3 col, Mesh *mesh, GLint *shaderVars) {
   expired = false;
   position = pos;
   joint = vec3(0);
   rotationAngle = 0;
   rotationAxis = vec3(0);
   scale = vec3(1);
   collider.minPos = min;
   collider.maxPos = max;
   color = col;
   model = mesh;
   boundingBox = GeometryCreator::CreateCube(max - min);
   h_uModelMatrix = shaderVars[0];
   h_aPosition = shaderVars[1];
   h_aNormal = shaderVars[2];
   h_uColor = shaderVars[3];
   gravity = GRAVITY;
}

list<Object> Object::hitsBuilding(list<Object> * buildings) {
    list<Object> hits;
    for(list<Object>::iterator it = buildings->begin(); it != buildings->end(); it++) {
        if (collides(*it)) {
           hits.push_back((Object)*it);
        }
    }
    return hits;
}

//x -> 1 means that it collides on the z axis
//y -> + means that it can't move in the - direction
vec3 Object::checkPaths(Object b) {
   vec3 info = vec3(0);
   if (abs(zDirection(b)) > abs(xDirection(b))) {
      info.x = 1;
      info.y = zDirection(b);
   } else {
      info.y = xDirection(b);
   }
   return info;
}

void Object::SetModel(RenderingHelper * ModelTrans) {
    safe_glUniformMatrix4fv(h_uModelMatrix, glm::value_ptr(ModelTrans->modelViewMatrix));
}

void Object::Draw(RenderingHelper * ModelTrans) {
    Mesh *mesh;
    if (DRAW_BOUNDINGBOX) {
       mesh = boundingBox;
    } else {
       mesh = model;
    }
    
    ModelTrans->pushMatrix();
    safe_glEnableVertexAttribArray(h_aPosition);
    glBindBuffer(GL_ARRAY_BUFFER, mesh->PositionHandle);
    safe_glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);

    safe_glEnableVertexAttribArray(h_aNormal);
    glBindBuffer(GL_ARRAY_BUFFER, mesh->NormalHandle);
    safe_glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->IndexHandle);

    glUniform3f(h_uColor, color.x, color.y, color.z);

    ModelTrans->translate(position);
    if (rotationAngle) {
        ModelTrans->rotate(rotationAngle, rotationAxis);
        ModelTrans->translate(joint);
    }
    ModelTrans->scale(scale.x, scale.y, scale.z);
    
    SetModel(ModelTrans);
    glDrawElements(GL_TRIANGLES, mesh->IndexBufferLength, GL_UNSIGNED_SHORT, 0);
    
    // Draw all the components (recursively)
    for (list<Object>::iterator it = components.begin(); it != components.end(); it++) {
       it->Draw(ModelTrans);
    }
    
    ModelTrans->popMatrix();
}

bool Object::collides(Object other) {
   vec3 min = position + collider.minPos;
   vec3 max = position + collider.maxPos;
   vec3 omin = other.position + other.collider.minPos;
   vec3 omax = other.position + other.collider.maxPos; 
   // If either are box-style colliders use box collision
   if ((min.x < omin.x && max.x > omin.x) || (min.x < omax.x && max.x > omax.x)) {
      if ((min.y < omin.y && max.y > omin.y) || (min.y < omax.y && max.y > omax.y)) {
         if ((min.z < omin.z && max.z > omin.z) || (min.z < omax.z && max.z > omax.z)) {
            return true;
         }
      }
   }
   if ((omin.x < min.x && omax.x > min.x) || (omin.x < max.x && omax.x > max.x)) {
      if ((omin.y < min.y && omax.y > min.y) || (omin.y < max.y && omax.y > max.y)) {
         if ((omin.z < min.z && omax.z > min.z) || (omin.z < max.z && omax.z > max.z)) {
            return true;
         }
      }
   }
   return false;
}

int Object::zDirection(Object other) {
   vec3 min = position + collider.minPos;
   vec3 max = position + collider.maxPos;
   vec3 omin = other.position + other.collider.minPos;
   vec3 omax = other.position + other.collider.maxPos; 
   return (min.z + max.z) - (omin.z + omax.z);
}

int Object::xDirection(Object other) {
   vec3 min = position + collider.minPos;
   vec3 max = position + collider.maxPos;
   vec3 omin = other.position + other.collider.minPos;
   vec3 omax = other.position + other.collider.maxPos; 
   return (min.x + max.x) - (omin.x + omax.x);
}

void Object::onHit(float damage) {
   //nothing
}
