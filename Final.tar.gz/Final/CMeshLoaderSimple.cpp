#include "CMeshLoaderSimple.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp" //perspective, trans etc
#include "glm/gtc/type_ptr.hpp" //value_ptr

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <math.h>
#include <iomanip>
#include <string>
#include <streambuf>

using namespace std;
using namespace glm;

class SColor
{

    public:

        float Red, Green, Blue;

        SColor()
            : Red(0.7f), Green(0.7f), Blue(0.7f)
        {}

};

class SVector3
{

    public:

        float X, Y, Z;

        SVector3()
            : X(0), Y(0), Z(0)
        {}

        SVector3(float in)
            : X(in), Y(in), Z(in)
        {}

        SVector3(float in_x, float in_y, float in_z)
            : X(in_x), Y(in_y), Z(in_z)
        {}

        SVector3 crossProduct(SVector3 const & v) const
        {
            return SVector3(Y*v.Z - v.Y*Z, v.X*Z - X*v.Z, X*v.Y - v.X*Y);
        }

        float dotProduct(SVector3 const & v) const
        {
            return X*v.X + Y*v.Y + Z*v.Z;
        }

        float length() const
        {
            return sqrtf(X*X + Y*Y + Z*Z);
        }

        SVector3 operator + (SVector3 const & v) const
        {
            return SVector3(X+v.X, Y+v.Y, Z+v.Z);
        }

        SVector3 & operator += (SVector3 const & v)
        {
            X += v.X;
            Y += v.Y;
            Z += v.Z;

            return * this;
        }

        SVector3 operator - (SVector3 const & v) const
        {
            return SVector3(X-v.X, Y-v.Y, Z-v.Z);
        }

        SVector3 & operator -= (SVector3 const & v)
        {
            X -= v.X;
            Y -= v.Y;
            Z -= v.Z;

            return * this;
        }

        SVector3 operator * (SVector3 const & v) const
        {
            return SVector3(X*v.X, Y*v.Y, Z*v.Z);
        }

        SVector3 & operator *= (SVector3 const & v)
        {
            X *= v.X;
            Y *= v.Y;
            Z *= v.Z;

            return * this;
        }

        SVector3 operator / (SVector3 const & v) const
        {
            return SVector3(X/v.X, Y/v.Y, Z/v.Z);
        }

        SVector3 & operator /= (SVector3 const & v)
        {
            X /= v.X;
            Y /= v.Y;
            Z /= v.Z;

            return * this;
        }

        SVector3 operator * (float const s) const
        {
            return SVector3(X*s, Y*s, Z*s);
        }

        SVector3 & operator *= (float const s)
        {
            X *= s;
            Y *= s;
            Z *= s;

            return * this;
        }

        SVector3 operator / (float const s) const
        {
            return SVector3(X/s, Y/s, Z/s);
        }

        SVector3 & operator /= (float const s)
        {
            X /= s;
            Y /= s;
            Z /= s;

            return * this;
        }

};

class SVertex
{

    public:

        SVector3 Position;
        SColor Color;

};

class CMesh
{

    friend class CVertexBufferObject;
    friend class CMeshLoader;

    struct STriangle
    {
        unsigned int VertexIndex1, VertexIndex2, VertexIndex3;
        SColor Color;
    };


    CMesh();

    public:

    std::vector<SVertex> Vertices;
    std::vector<STriangle> Triangles;

    ~CMesh();
    
    vec3 getMiddleByExtents();

    void centerMeshByAverage(SVector3 const & CenterLocation);
    void centerMeshByExtents(SVector3 const & CenterLocation);

    void resizeMesh(SVector3 const & Scale);

};

vec3 CMesh::getMiddleByExtents() {
   vec3 mins = vec3(9999, 9999, 9999);
   vec3 maxes = vec3(-9999, -9999, -9999);
   for(int i = 0; i < Vertices.size(); i++) {
      SVector3 pos = Vertices.at(i).Position;
      if (pos.X < mins.x) {
         mins.x = pos.X;
      }
      if (pos.X > maxes.x) {
         maxes.x = pos.X;
      }
      if (pos.Y < mins.y) {
         mins.y = pos.Y;
      }
      if (pos.Y > maxes.y) {
         maxes.y = pos.Y;
      }
      if (pos.Z < mins.z) {
         mins.z = pos.Z;
      }
      if (pos.Z > maxes.z) {
         maxes.z = pos.Z;
      }
   }
   return vec3((maxes.x + mins.x) / 2, (maxes.y + mins.y) / 2, (maxes.z + mins.z) / 2);
}

void fillVertices(CMesh Mesh, float *vertices, int verticesCount) {
    for(int i = 0; i < verticesCount; i++) {
         vertices[i*3] = Mesh.Vertices.at(i).Position.X;
         vertices[i*3+1] = Mesh.Vertices.at(i).Position.Y;
         vertices[i*3+2] = Mesh.Vertices.at(i).Position.Z;
    }
}

void fillIndices(CMesh Mesh, unsigned short *indices, int TriangleCount) {
    for(int i = 0; i < TriangleCount; i++) {
         indices[i*3] = Mesh.Triangles.at(i).VertexIndex1;
         indices[i*3+1] = Mesh.Triangles.at(i).VertexIndex2;
         indices[i*3+2] = Mesh.Triangles.at(i).VertexIndex3;
    }
}

void fillNormals(CMesh Mesh, float *normals, const float *vertices, unsigned short *indices, int TriangleCount) {
   for (int i = 0; i < TriangleCount; i++) {
      vec3 point1 = vec3(vertices[indices[i*3]*3], vertices[indices[i*3]*3 + 1], vertices[indices[i*3]*3 + 2]);
      vec3 point2 = vec3(vertices[indices[i*3+1]*3], vertices[indices[i*3+1]*3 + 1], vertices[indices[i*3+1]*3 + 2]);
      vec3 point3 = vec3(vertices[indices[i*3+2]*3], vertices[indices[i*3+2]*3 + 1], vertices[indices[i*3+2]*3 + 2]);
      vec3 line1 = point1 - point2;
      vec3 line2 = point1 - point3;
      vec3 axis = cross(line1, line2);
      axis = normalize(axis);
      
      for (int j = 0; j < 3; j++) {
         normals[indices[i*3 + j]*3] += axis.x;
         normals[indices[i*3 + j]*3+1] += axis.y;
         normals[indices[i*3 + j]*3+2] += axis.z;
      }
   }
}

void fillColors(CMesh Mesh, float *colors, int verticesCount) {
    for(int i = 0; i < verticesCount; i++) {
         colors[i*3] = .6;
         colors[i*3+1] = .4;
         colors[i*3+2] = 0;
    }
}

void CMeshLoader::createVertexBufferObject(CMesh const & Mesh, int & TriangleCount, GLuint & PositionBufferHandle, GLuint & IndexBufferHandle, GLuint & ColorBufferHandle, GLuint & NormalBufferHandle) {

    float *vertices = (float *)calloc(Mesh.Vertices.size() * 3, sizeof(float));
    float *colors = (float *)calloc(Mesh.Vertices.size() * 3, sizeof(float));
    unsigned short *indices = (unsigned short *)calloc(TriangleCount * 3, sizeof(unsigned short));
    float *normals = (float *)calloc(Mesh.Vertices.size() * 3, sizeof(float));
    
    fillVertices(Mesh, vertices, Mesh.Vertices.size());
    fillIndices(Mesh, indices, TriangleCount);
    fillColors(Mesh, colors, Mesh.Vertices.size());
    fillNormals(Mesh, normals, vertices, indices, TriangleCount);

    size_t vcSize = sizeof(float) * TriangleCount * 9;
    size_t idxSize = sizeof(unsigned short) * TriangleCount * 3;

    glGenBuffers(1, &PositionBufferHandle);
    glBindBuffer(GL_ARRAY_BUFFER, PositionBufferHandle);
    glBufferData(GL_ARRAY_BUFFER, vcSize, vertices, GL_STATIC_DRAW);
    
    glGenBuffers(1, &ColorBufferHandle);
    glBindBuffer(GL_ARRAY_BUFFER, ColorBufferHandle);
    glBufferData(GL_ARRAY_BUFFER, vcSize, colors, GL_STATIC_DRAW);

    glGenBuffers(1, &IndexBufferHandle);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferHandle);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, idxSize, indices, GL_STATIC_DRAW);
    
    glGenBuffers(1, &NormalBufferHandle);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, NormalBufferHandle);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, vcSize, normals, GL_STATIC_DRAW);

    //free(vertices);
    //free(indices);
    //free(colors);
}

bool CMeshLoader::loadVertexBufferObjectFromMesh(std::string const & fileName, int & TriangleCount, GLuint & PositionBufferHandle, GLuint & IndexBufferHandle, GLuint & ColorBufferHandle, GLuint & NormalBufferHandle)
{
    CMesh * Mesh = loadASCIIMesh(fileName);
    TriangleCount = Mesh->Triangles.size();

    if (! Mesh)
        return false;
   
    vec3 size = Mesh->getMiddleByExtents();
    float scale = .8 / glm::max(glm::max(size.x, size.y), size.z);
    Mesh->resizeMesh(SVector3(scale));
    //Mesh->centerMeshByExtents(SVector3(0));
    Mesh->centerMeshByAverage(SVector3(0));

    createVertexBufferObject (*Mesh, TriangleCount, PositionBufferHandle, IndexBufferHandle, ColorBufferHandle, NormalBufferHandle);

    return true;
}

CMesh * const CMeshLoader::loadASCIIMesh(std::string const & fileName)
{
    std::ifstream File;
    File.open(fileName.c_str());

    if (! File.is_open())
    {
        std::cerr << "Unable to open mesh file: " << fileName << std::endl;
        return 0;
    }

    CMesh * Mesh = new CMesh();

    while (File)
    {
        std::string ReadString;
        std::getline(File, ReadString);

        std::stringstream Stream(ReadString);

        std::string Label;
        Stream >> Label;

        if (Label.find("#") != std::string::npos)
        {
            // Comment, skip
            continue;
        }

        if ("Vertex" == Label)
        {
            int Index;
            Stream >> Index; // We don't care, throw it away

            SVector3 Position;
            Stream >> Position.X;
            Stream >> Position.Y;
            Stream >> Position.Z;

            SVertex Vertex;
            Vertex.Position = Position;

            Mesh->Vertices.push_back(Vertex);
        }
        else if ("Face" == Label)
        {
            int Index;
            Stream >> Index; // We don't care, throw it away

            int Vertex1, Vertex2, Vertex3;
            Stream >> Vertex1;
            Stream >> Vertex2;
            Stream >> Vertex3;

            CMesh::STriangle Triangle;
            Triangle.VertexIndex1 = Vertex1 - 1;
            Triangle.VertexIndex2 = Vertex2 - 1;
            Triangle.VertexIndex3 = Vertex3 - 1;

            size_t Location;
            if ((Location = ReadString.find("{")) != std::string::npos) // there is a color
            {
                Location = ReadString.find("rgb=(");
                Location += 5; // rgb=( is 5 characters

                ReadString = ReadString.substr(Location);
                std::stringstream Stream(ReadString);
                float Color;
                Stream >> Color;
                Triangle.Color.Red = Color;
                Stream >> Color;
                Triangle.Color.Green = Color;
                Stream >> Color;
                Triangle.Color.Blue = Color;
            }

            Mesh->Triangles.push_back(Triangle);
        }
        else if ("" == Label)
        {
            // Just a new line, carry on...
        }
        else if ("Corner" == Label)
        {
            // We're not doing any normal calculations... (oops!)
        }
        else
        {
            std::cerr << "While parsing ASCII mesh: Expected 'Vertex' or 'Face' label, found '" << Label << "'." << std::endl;
        }
    }

    if (! Mesh->Triangles.size() || ! Mesh->Vertices.size())
    {
        delete Mesh;
        return 0;
    }

    return Mesh;
}



CMesh::CMesh()
{}

CMesh::~CMesh()
{}

void CMesh::centerMeshByAverage(SVector3 const & CenterLocation)
{
   vec3 avg = vec3(0);
   for(int i = 0; i < Vertices.size(); i++) {
      SVector3 pos = Vertices.at(i).Position;
      avg.x += pos.X;
      avg.y += pos.Y;
      avg.z += pos.Z;
   }
   avg.x /= Vertices.size();
   avg.y /= Vertices.size();
   avg.z /= Vertices.size();
   vec3 shift = vec3(avg.x - CenterLocation.X, avg.y - CenterLocation.Y, avg.z - CenterLocation.Z);
   for (int i = 0; i < Vertices.size(); i++) {
      Vertices.at(i).Position.X -= shift.x;
      Vertices.at(i).Position.Y -= shift.y;
      Vertices.at(i).Position.Z -= shift.z;
   }
}

void CMesh::centerMeshByExtents(SVector3 const & CenterLocation)
{
   vec3 middles = getMiddleByExtents();
   vec3 shift = vec3(middles.x - CenterLocation.X, middles.y - CenterLocation.Y, middles.z - CenterLocation.Z);
   for (int i = 0; i < Vertices.size(); i++) {
      Vertices.at(i).Position.X -= shift.x;
      Vertices.at(i).Position.Y -= shift.y;
      Vertices.at(i).Position.Z -= shift.z;
   }
}

void CMesh::resizeMesh(SVector3 const & Scale)
{
   for(int i = 0; i < Vertices.size(); i++) {
      Vertices.at(i).Position.X *= Scale.X;
      Vertices.at(i).Position.Y *= Scale.Y;
      Vertices.at(i).Position.Z *= Scale.Z;
   }
}
