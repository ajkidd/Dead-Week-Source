#include "Building.h"

Building::Building(vec3 pos, float angle, GLint *shaderVars) : Object(vec3(pos.x, pos.y+11, pos.z),
 vec3(-5, -11, -5), vec3(5, 11, 5), vec3(0.457, 0.371, 0.277), GeometryCreator::CreateCube(vec3(10.f, 22.f, 10.f)), shaderVars) {
    Object::rotationAngle = angle;
    Object::rotationAxis = vec3(0, 1, 0);
    createBuilding();
}

Building::Building(int type, vec3 pos, float angle, GLint *shaderVars) : Object(vec3(pos.x, pos.y+11, pos.z),
 vec3(-5, -11, -5), vec3(5, 11, 5), vec3(0.457, 0.371, 0.277), GeometryCreator::CreateCube(vec3(23.f, 22.f, 10.f)), shaderVars) {
    Object::rotationAngle = angle;
    Object::rotationAxis = vec3(0, 1, 0);
}

void Building::createBuilding() {
    GLint shaderVars[4] = { h_uModelMatrix, h_aPosition, h_aNormal, h_uColor };
    vec3 pos = vec3(0, 0, 0);
    vec3 ref = pos; //Reference point to buildings position
    vec3 color = Object::color;
    float radius = Object::radius;
    float miny = Object::minY;
    float maxy = Object::maxY;

    /***** Buildings components *****/

    //Door
    pos.y -= 8.6; pos.z += 4.55;
    vec3 doorRef = pos;
    Object door = Object(pos, vec3(0), vec3(0), vec3(0.539), GeometryCreator::CreateCube(vec3(1.5, 4.5, 1.f)), shaderVars);
    Object::components.push_back(door);

    //Windows
    pos = doorRef; pos.x += 3; pos.y += 3;
    Object window = Object(pos, vec3(0), vec3(0), vec3(0.23, 0.242, 0.167), GeometryCreator::CreateCube(vec3(1.5, 3, 1.f)), shaderVars);

    //Right row of windows
    for(int i = 0; i < 3; i++) {
        Object::components.push_back(window);
        window.position.y += 6;
    }

    //Left row of windows
    window.position.x -= 6;
    window.position.y -= 6;
    for(int i = 0; i < 3; i++) {
        Object::components.push_back(window);
        window.position.y -= 6;
    }
}
