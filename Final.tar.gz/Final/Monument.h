#ifndef __MONUMENT__
#define __MONUMENT__

#include "resources.h"
#include "Object.h"
#include "Camera.h"

#define COLOR_INCREMENT 0.006
#define DIST 40
#define HEALING .5
#define HEAL_COOLDOWN 1

using namespace std;
using namespace glm;

class Monument : public Object {
    private:
        float scaleBy;
        float cur, prev;
        int cooldown;

    public:
        Monument(char *file, vec3 pos, GLint *shaderVars);
        void animate(Camera *c);

    private:
        void buildMonument(char *file);
        Object get(int index);
        void update(int index, Object o);
        void dist(Camera *c);
};

#endif
