#include "Map.h"

Map::Map(char *file, GLint *shaderVars) {
    this->shaderVars = shaderVars;
    this->file = file;
    probability = 60;
    count = 0;
    respawnCount = 0;
    initWorld(file);
}

void Map::respawn() {
    Mesh *sphereMesh = GeometryCreator::CreateSphere(vec3(0.3));
    int randNum = 0;
    char data[CHARS_PER_LINE];
    bool street = false;
    int zPos = 0;
    int xPos = 0;

    srand(time(NULL));
    ifstream fin;
    fin.open(file);

    while(!fin.eof()) {
        fin.getline(data, CHARS_PER_LINE);

        for(int i = 0; data[i] != '\0'; i++) {
            switch(data[i]) {
            case '-': case '+': case 'c': case 'm':
                xPos += 16;
                break;
            case '|': case 'd': case 'u': case 'l': case 'r': case ' ':
                xPos += 10;
                break;
            case '>':
                xPos += 10;

                if(!street)
                    street = true;

                randNum = rand() % 100;

                if(randNum < probability / 3.0 && numZombies < MAX_ZOMBIES) {
                    if(count < RESPAWN_ZOMBIES) {
                        Zombie z = Zombie(vec3(xPos-8, 2.4, zPos), vec3((rand()%100)/100.0, (rand()%100)/100.0, 0), sphereMesh, shaderVars);
                        z.scale = vec3(2);
                        z.position.y = 4.7;
                        zombies.push_back(z);
                        count++;
                        numZombies++;
                    }
                }

                break;
            case '^':
                xPos += 16;

                randNum = rand() % 100;

                if(randNum < probability / 3.0 && numZombies < MAX_ZOMBIES) {
                    if(count < RESPAWN_ZOMBIES) {
                        Zombie z = Zombie(vec3(xPos-8, 2.4, zPos), vec3((rand()%100)/100.0, (rand()%100)/100.0, 0), sphereMesh, shaderVars);
                        z.scale = vec3(2);
                        z.position.y = 4.7;
                        zombies.push_back(z);
                        count++;
                        numZombies++;
                    }
                }

                break;
            default:
                cout << "Key not recognized check text file" << endl;
                exit( EXIT_FAILURE );
                break;
            }
        }

        if(street) {
            zPos += 6;
            street = false;
        }
        xPos = 0;
        zPos += 10;
    }

    fin.close();
    count = 0;
}

void Map::initWorld(char *file) {
    Mesh *sphereMesh = GeometryCreator::CreateSphere(vec3(0.3));
    //zombies.push_back(Zombie(vec3(0, 2.4, 0), vec3((rand()%100)/100.0, (rand()%100)/100.0, 0), sphereMesh, shaderVars));
    int randNum = 0;
    char data[CHARS_PER_LINE];
    bool street = false;
    int zPos = 0;
    int xPos = 0;

    srand(time(NULL));
    ifstream fin;
    fin.open(file);

    if(!fin.good()) {
        cout << "File not found" << endl;
        exit( EXIT_FAILURE );
    }

    cout << endl;
    while(!fin.eof()) {
        fin.getline(data, CHARS_PER_LINE);

        for(int i = 0; data[i] != '\0'; i++) {
            cout << data[i];

            switch(data[i]) {
            case '-':
                buildings.push_back((Object)Building(WALL, vec3(xPos, 0, zPos), 0, shaderVars));
                xPos += 16;
                break;
            case '|':
                buildings.push_back((Object)Building(WALL, vec3(xPos, 0, zPos), 90, shaderVars));
                xPos += 10;
                break;
            case 'd':
                buildings.push_back((Object)Building(vec3(xPos, 0, zPos), 0, shaderVars));
                xPos += 10;
                break;
            case 'u':
                buildings.push_back((Object)Building(vec3(xPos, 0, zPos), 180, shaderVars));
                xPos += 10;
                break;
            case 'l':
                buildings.push_back((Object)Building(vec3(xPos, 0, zPos), -90, shaderVars));
                xPos += 10;
                break;
            case 'r':
                buildings.push_back((Object)Building(vec3(xPos, 0, zPos), 90, shaderVars));
                xPos += 10;
                break;
            case '>':
                sidewalks.push_back(Path(vec3(xPos, 0, zPos), SIDEWALK, 0, 90, shaderVars));
                streets.push_back(Path(vec3(xPos, 0, zPos+3), STREET, 0, 90, shaderVars));
                sidewalks.push_back(Path(vec3(xPos, 0, zPos+12), SIDEWALK, 0, 90, shaderVars));
                xPos += 10;

                if(!street)
                    street = true;

                randNum = rand() % 100;

                if(randNum < probability) {
                    if(count < NUM_OF_ZOMBIES) {
                        Zombie z = Zombie(vec3(xPos-8, 2.4, zPos), vec3((rand()%100)/100.0, (rand()%100)/100.0, 0), sphereMesh, shaderVars);
                        z.scale = vec3(2);
                        z.position.y = 4.7;
                        zombies.push_back(z);
                        count++;
                        numZombies++;
                    }
                }

                break;
            case '^':
                sidewalks.push_back(Path(vec3(xPos-3, 0, zPos+3), SIDEWALK, 0, 0, shaderVars));
                streets.push_back(Path(vec3(xPos+3, 0, zPos), STREET, 0, 0, shaderVars));
                sidewalks.push_back(Path(vec3(xPos+9, 0, zPos+3), SIDEWALK, 0, 0, shaderVars));
                xPos += 16;

                randNum = rand() % 100;

                if(randNum < probability) {
                    if(count < NUM_OF_ZOMBIES) {
                        Zombie z = Zombie(vec3(xPos-8, 2.4, zPos), vec3((rand()%100)/100.0, (rand()%100)/100.0, 0), sphereMesh, shaderVars);
                        z.scale = vec3(2);
                        z.position.y = 4.7;
                        zombies.push_back(z);
                        count++;
                        numZombies++;
                    }
                }

                break;
            case '+':
                intersections.push_back(Path(vec3(xPos, 0, zPos+6), INTERSECTION, 0, 0, shaderVars));
                xPos += 16;
                break;
            case 'c':
                intersections.push_back(Path(vec3(xPos, 0, zPos+6), INTERSECTION, 0, 0, shaderVars));
                cameraPos = vec3(xPos, 4.7, zPos);
                cameraLookAt = vec3(xPos, 4.7, zPos + 1);
                xPos += 16;
                break;
            case 'm':
                buildings.push_back((Object)Monument((char *)"", vec3(xPos+2, 4, zPos+3), shaderVars));
                intersections.push_back(Path(vec3(xPos, 0, zPos+6), INTERSECTION, 0, 0, shaderVars));
                monuments.push_back(Monument((char *)"Models/dragon10k.m", vec3(xPos+2, 4, zPos+3), shaderVars));
                intersections.push_back(Path(vec3(xPos, 0, zPos+6), INTERSECTION, 0, 0, shaderVars));
                xPos += 16;
                break;
            case ' ':
                xPos += 10;
                break;
            default:
                cout << "Key not recognized check text file" << endl;
                exit( EXIT_FAILURE );
                break;
            }
        }

        if(street) {
            zPos += 6;
            street = false;
        }
        cout << endl;
        xPos = 0;
        zPos += 10;
    }

    fin.close();
    count = 0;
}

