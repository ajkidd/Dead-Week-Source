#ifndef __OBJECT__
#define __OBJECT__

#include "resources.h"

#define GRAVITY .005
#ifdef BOUNDINGBOX
   #define DRAW_BOUNDINGBOX 1
#else
   #define DRAW_BOUNDINGBOX 0
#endif

using namespace std;
using namespace glm;

typedef struct Collider {
   vec3 minPos;
   vec3 maxPos;
} Collider;

class Object {
   
   public:
      bool expired;
      
      vec3 joint;
      vec3 position;
      vec3 color;
      Collider collider;
      
      //Cylinder Collider
      float radius;
      float minY, maxY;

      float rotationAngle;
      vec3 rotationAxis;

      vec3 scale;
      
      list<Object> components;
      Mesh *model;
      Mesh *boundingBox;
      
      float gravity;
      
      GLint h_uModelMatrix;
      GLint h_aPosition;
      GLint h_aNormal;
      GLint h_uColor;
      
   public:
      Object(vec3 position, vec3 min, vec3 max, vec3 color, Mesh *mesh, GLint *shaderVars);
      Object(vec3 position, vec3 joint, float roationAngle, vec3 rotationAxis, vec3 min, vec3 max, vec3 color, Mesh *mesh, GLint *shaderVars);
      void Draw(RenderingHelper * ModelTrans);
      bool collides(Object other);
      int zDirection(Object other);
      int xDirection(Object other);
      void onHit(float damage);
      list<Object> hitsBuilding(list<Object> * buildings);
      vec3 checkPaths(Object b);
      
   private:
      void SetModel(RenderingHelper * ModelTrans);      
   
};

#endif
