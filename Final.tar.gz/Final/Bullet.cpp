#include "Object.h"
#include "Bullet.h"

Bullet::Bullet(vec3 pos, vec3 dir, vec3 col, Mesh *m, GLint *shaderVars) :
 Object(pos, vec3(-.5, -.5, -.5), vec3(.5, .5, .5), col, m, shaderVars) {
   direction = normalize(dir);
   speed = BULLET_SPEED;
   damage = DAMAGE;
}

void Bullet::move() {
   position -= speed * direction;
   position.y -= gravity;
   gravity += GRAVITY;
   rotationAngle += ROTATE_INCREMENT;
   rotationAxis = normalize(vec3((rand() % 200) / 100.0 - 1, (rand() % 100) / 100.0 - 1, (rand() % 100) / 100.0 - 1));
}

bool Bullet::hits(Object *o) {
   if (collides(*o)) {
      o->onHit(damage);
      return (expired = true);
   }
   return false;
}

bool Bullet::hits(Zombie *z) {
   if (collides((Object)*z)) {
      z->onHit(damage);
      return (expired = true);
   }
   return false;
}
