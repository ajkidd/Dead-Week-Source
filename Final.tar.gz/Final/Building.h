#ifndef __BUILDING__
#define __BUILDING__

#include "resources.h"
#include "Object.h"

using namespace std;
using namespace glm;

class Building : public Object {
    private:
        void createBuilding();

    public:
        Building(vec3 position, float angle, GLint *shaderVars);
        Building(int type, vec3 position, float angle, GLint *shaderVars);
};

#endif
