#include "Path.h"

Path::Path(vec3 pos, int type, int tiles, float angle, GLint *shaderVars) : Object(pos, 
 vec3(-10, -.5, -10), vec3(10, .5, 10), vec3(0), GeometryCreator::CreateCube(vec3(0)), shaderVars) {
    this->tiles = tiles;
    Object::rotationAngle = angle;
    Object::rotationAxis = vec3(0, 1, 0);

    if(type == STREET)
        createStreet();
    else if(type == INTERSECTION)
        createIntersection();
    else if(type == SIDEWALK)
        createSidewalk();
}

void Path::createStreet() {
    GLint shaderVars[4] = { h_uModelMatrix, h_aPosition, h_aNormal, h_uColor };
    vec3 pos = vec3(0);
    vec3 black = vec3(0);
    vec3 yellow = vec3(0.99, 0.937, 0.019);
    float radius = Object::radius;
    float miny = Object::minY;
    float maxy = Object::maxY;

    /****** Street components *****/

    Object::color = black;
    Object::model = GeometryCreator::CreateCube(vec3(8.f, 1.f, 10.f));
    Object street = Object(pos, vec3(0), vec3(0), black, GeometryCreator::CreateCube(vec3(8.f, 1.f, 10.f)), shaderVars);

    Object stripe = Object(pos, vec3(0), vec3(0), yellow, GeometryCreator::CreateCube(vec3(2.f, 1.1f, 4.f)), shaderVars);
    Object::components.push_back(stripe);

    for(int i = 0; i < tiles; i++) {
       street.position.z -= 10;
       stripe.position.z -= 10;
       Object::components.push_back(street);
       Object::components.push_back(stripe);
    }
}

void Path::createIntersection() {
    GLint shaderVars[4] = { h_uModelMatrix, h_aPosition, h_aNormal, h_uColor };
    vec3 pos = vec3(0);
    vec3 ref = pos;
    vec3 black = vec3(0);
    vec3 gray = vec3(0.55, 0.656, 0.574);
    float radius = Object::radius;
    float miny = Object::minY;
    float maxy = Object::maxY;

    /****** Intersection components *****/

    Object::color = black;
    Object::rotationAngle = 90;
    Object::rotationAxis = vec3(0, 1, 0);
    Object::position.z -= 3;
    Object::position.x += 3;
    Object::model = GeometryCreator::CreateCube(vec3(8, 1, 16));

    Object street = Object(pos, vec3(0), vec3(0), black, Object::model, shaderVars);
    street.rotationAngle = 90;
    street.rotationAxis = vec3(0, 1, 0);
    Object::components.push_back(street);

    pos.x += 6; pos.z -= 6;
    Object sidewalk = Object(pos, vec3(0), vec3(0), gray, GeometryCreator::CreateCube(vec3(4, 1, 4)), shaderVars);
    Object::components.push_back(sidewalk);

    sidewalk.position = ref; sidewalk.position.x += 6; sidewalk.position.z += 6;
    Object::components.push_back(sidewalk);

    sidewalk.position = ref; sidewalk.position.x -= 6; sidewalk.position.z += 6;
    Object::components.push_back(sidewalk);

    sidewalk.position = ref; sidewalk.position.x -= 6; sidewalk.position.z -= 6;
    Object::components.push_back(sidewalk);

    //Right stripes
    /*pos.x += 8; pos.y += 0.1;
    Object stripe = Object(pos, radius, miny, maxy, yellow, GeometryCreator::CreateCube(vec3(1.f, 1.f, 8.f)), shaderVars);
    Object::components.push_back(stripe);

    stripe.position.x -= 3.5;
    Object::components.push_back(stripe);

    //Left Stripes
    stripe.position = ref; stripe.position.x -= 8; stripe.position.y += 0.1;
    Object::components.push_back(stripe);

    stripe.position.x += 3.5;
    Object::components.push_back(stripe);

    //Bottom Stripes
    stripe.rotationAngle = 90;
    stripe.rotationAxis = vec3(0, 1, 0);
    stripe.position = ref; stripe.position.z += 8; stripe.position.y += 0.1;
    Object::components.push_back(stripe);

    stripe.position.z -= 3.5;
    Object::components.push_back(stripe);

    //Top Stripes
    stripe.position = ref; stripe.position.z -= 8; stripe.position.y += 0.1;
    Object::components.push_back(stripe);

    stripe.position.z += 3.5;
    Object::components.push_back(stripe);*/
}

void Path::createSidewalk() {
    GLint shaderVars[4] = { h_uModelMatrix, h_aPosition, h_aNormal, h_uColor };
    vec3 pos = vec3(0);
    vec3 gray = vec3(0.55, 0.656, 0.574);
    float radius = Object::radius;
    float miny = Object::minY;
    float maxy = Object::maxY;

    /****** Sidewalk components *****/

    Object::position.z -= 3;
    Object::color = gray;
    Object::model = GeometryCreator::CreateCube(vec3(4.f, 1.f, 10.f));
    Object sidewalk = Object(pos, vec3(0), vec3(0), gray, GeometryCreator::CreateCube(vec3(4.f, 1.f, 10.f)), shaderVars);

    for(int i = 0; i < tiles; i++) {
       sidewalk.position.z -= 10;
       Object::components.push_back(sidewalk);
    }
}
