#ifndef __BULLET__
#define __BULLET__

#include "resources.h"
#include "Object.h"
#include "Zombie.h"

#define BULLET_SPEED .8
#define DAMAGE 5.0
#define ROTATE_INCREMENT 10

using namespace std;
using namespace glm;

class Bullet : public Object {
   
   public:
      vec3 direction;
      float speed;
      float damage;
      
   public:
      Bullet(vec3 position, vec3 direction, vec3 color, Mesh *mesh, GLint *shaderVars);
      void move();
      bool hits(Object * o);
      bool hits(Zombie * z);
   
};

#endif
