#ifndef _CAMERA_H_
#define _CAMERA_H_

#include "resources.h"
#include "Object.h"

#define WIDTH_DEG 1440
#define HEIGHT_DEG 720
#define HEIGHT_LIMIT (50.0 * (M_PI/180))
#define RADIUS 0.1
#define RADIUS_Y 1
#define EYE_HEIGHT 4.7f
#define MAX_PLAYER_HEALTH 100

using namespace std;
using namespace glm;

class Camera {
      
    public:
        vec3 eye;
        vec3 lookAt;
        vec3 lookAtPoint;
        vec3 up;
        vec2 cur;
        vec2 prev;
        float fly;
        float health;
        Object *object;
        vec3 blood;

    private:
        vec3 u, v, w;
        float width;
        float height;
        float step;
        float pitch; //phi - change in y
        float yaw; //theta - change in x

    public:
        Camera(float, float, GLint *shaderVars);
        Camera(vec3, vec3, vec3, float, float, float, GLint *shaderVars);
        void groundEyes();
        void moveForward(list<Object> * buildings);
        void moveBack(list<Object> * buildings);
        void moveRight(list<Object> * buildings);
        void moveLeft(list<Object> * buildings);
        void mouseMove();
        void screen(float, float);
        void bleed();
        void heal();

    private:
        void moveToward(vec3 direction, list<Object> * buildings);
        void calculateBasisVectors();
        void printVectors();
        void printMouseMovement();
        float deg2rad(float);
        void updateObject(vec3 direction);

};

#endif
