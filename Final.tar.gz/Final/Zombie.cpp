#include "Zombie.h"

Zombie::Zombie(vec3 pos, vec3 col, Mesh *m, GLint *shaderVars) :
    Object(pos, vec3(-1, -2, -1), vec3(1, 2, 1), col, m, shaderVars) {
        health = MAX_HEALTH;
        speed = ZOMBIE_SPEED;
        cooldown = 0;
        move = true;
        rightLegRot = ROTATE_AMOUNT;
        leftLegRot = -1 * ROTATE_AMOUNT;
        rightArmRot = ROTATE_AMOUNT;
        leftArmRot = -1 * ROTATE_AMOUNT;
        atk = true;
        buildZombie();
    }

void Zombie::moveToward(vec3 destination, list<Object> * buildings) {
    vec3 direction = normalize(position - destination);
    vec3 oldPosition = position;
    position -= speed * direction;
    vec3 dir;
    list<Object> b = Object::hitsBuilding(buildings);
    float extraX = 0;
    float extraZ = 0;
    for(list<Object>::iterator it = b.begin(); it != b.end(); it++) {
        dir = Object::checkPaths(*it);
        if (dir.x == 0) {
            if (dir.y < 0 && direction.x < 0) {
                if (abs(direction.x) > extraX) {
                    extraZ = abs(direction.x);
                }
                direction.x = 0;
            }
            if (dir.y > 0 && direction.x > 0) {
                if (abs(direction.x) > extraX) {
                    extraZ = abs(direction.x);
                }
                direction.x = 0;
            }
        } else {
            if (dir.y < 0 && direction.z < 0) {
                if (abs(direction.z) > extraZ) {
                    extraX = abs(direction.z);
                }
                direction.z = 0;
            }
            if (dir.y > 0 && direction.z > 0) {
                if (abs(direction.z) > extraZ) {
                    extraX = abs(direction.z);
                }
                direction.z = 0;
            }
        }
    }
    if (direction.x) {
        if (direction.x > 0) {
            direction.x += extraX;
        } else {
            direction.x -= extraX;
        }
    }
    if (direction.z) {
        if (direction.z > 0) {
            direction.z += extraZ;
        } else {
            direction.z -= extraZ;
        }
    }
    position = oldPosition;
    position -= speed * direction;
}

void Zombie::onHit(float damage) {
    health -= damage;

    Object body = get(6);
    Object lArm = get(7);
    Object rArm = get(8);

    if(MAX_HEALTH/100 * 75 <= health) { //75% health
        body.color.r = 0.5;
        lArm.color.r = 0.5;
        rArm.color.r = 0.5;
        for(list<Object>::iterator i = lArm.components.begin(); i != lArm.components.end(); i++)
            i->color.r = 0.5;
        for(list<Object>::iterator i = rArm.components.begin(); i != rArm.components.end(); i++)
            i->color.r = 0.5;
    } else if(MAX_HEALTH/100 * 50 <= health) { //50% health
        body.color.r = 0.8;
        lArm.color.r = 0.8;
        rArm.color.r = 0.8;
        for(list<Object>::iterator i = lArm.components.begin(); i != lArm.components.end(); i++)
            i->color.r = 0.8;
        for(list<Object>::iterator i = rArm.components.begin(); i != rArm.components.end(); i++)
            i->color.r = 0.8;
    } else if(MAX_HEALTH/100 * 25 <= health) { //25% health
        body.color.r = 1;
        lArm.color.r = 1;
        rArm.color.r = 1;
        for(list<Object>::iterator i = lArm.components.begin(); i != lArm.components.end(); i++)
            i->color.r = 1;
        for(list<Object>::iterator i = rArm.components.begin(); i != rArm.components.end(); i++)
            i->color.r = 1;
    }
    update(6, body);
    update(7, lArm);
    update(8, rArm);


    if (health <= 0) {
        expired = true;
    }
}

void Zombie::buildZombie() {
    GLint shaderVars[4] = { h_uModelMatrix, h_aPosition, h_aNormal, h_uColor};
    vec3 pos = vec3(0, 0, 0);
    vec3 head = pos; //Reference point to zombies head position
    float radius = Object::radius;
    float miny = Object::minY;
    float maxy = Object::maxY;
    vec3 color = Object::color;
    vec3 skinColor = color;

    /****** Zombies body parts ******/

    //Zombies head components
    pos.y += 0.01f; pos.z += 0.24f; pos.x -= 0.08f;
    Object sclera = Object(pos, vec3(0), vec3(0), vec3(1, 1, 1), GeometryCreator::CreateSphere(vec3(0.1f)), shaderVars);
    Object::components.push_back(sclera); //0

    sclera.position.x += 0.2f;
    Object::components.push_back(sclera); //1

    pos.y += 0.05f; pos.z += 0.09f; pos.x -= 0.04f;
    Object eyeBall = Object(pos, vec3(0), vec3(0), vec3(0, 0, 0), GeometryCreator::CreateSphere(vec3(0.025f)), shaderVars);
    Object::components.push_back(eyeBall); //2

    eyeBall.position.x += 0.25f;
    eyeBall.position.y -= 0.05f;
    Object::components.push_back(eyeBall); //3

    pos = head; pos.y -= 0.15f; pos.z += 0.23f;
    Object mouth = Object(pos, vec3(0), vec3(0), vec3(1, 0, 0), GeometryCreator::CreateCube(vec3(0.2, 0.1, 0.1)), shaderVars);
    Object::components.push_back(mouth); //4

    //Zombies torso components
    vec3 shirtColor = vec3(0.441, 0.316, 0.218);
    vec3 jeansColor = vec3(0.109, 0.222, 0.277);
    pos = head; pos.y -= 0.3f; pos.z += 0.02f;
    vec3 torsoPos = pos; //Reference point to zombies torso position
    Object shoulders = Object(pos, vec3(0), vec3(0), shirtColor, GeometryCreator::CreateSphere(vec3(0.25f, 0.1f, 0.2f)), shaderVars);
    Object::components.push_back(shoulders); //5

    Object body = Object(pos, vec3(0), vec3(0), shirtColor, GeometryCreator::CreateCylinder(0.22f, 0.22f, 0.5f, 32, 16), shaderVars);
    body.rotationAngle = 90;
    body.rotationAxis = vec3(1, 0, 0);
    Object::components.push_back(body); //6

    //Zombies arms components
    pos = torsoPos; pos.x += 0.1f;
    vec3 armPos = pos; //Reference point to zombies right arm position
    Object arm = Object(pos, vec3(0), vec3(0), shirtColor, GeometryCreator::CreateCylinder(0.15f, 0.1f, 0.5f, 32, 16), shaderVars);
    arm.rotationAngle = 10;
    arm.rotationAxis = vec3(1, 0, 0);
    Object::components.push_back(arm); //7
    rightArm = 7;

    arm.position.x -= 0.2f;
    Object::components.push_back(arm); //8
    leftArm = 8;

    pos = armPos; pos.x -= 0.1f; pos.y += 0.3f; pos.z += 0.47f;
    vec3 forearmPos = pos;
    Object forearm = Object(pos, vec3(0), vec3(0), shirtColor, GeometryCreator::CreateCylinder(0.1f, 0.12f, 0.3f, 32, 16), shaderVars);
    forearm.rotationAngle = -5;
    forearm.rotationAxis = vec3(1, 0, 0);
    Object temp = get(rightArm);
    temp.components.push_back(forearm); //0
    update(rightArm, temp);

    forearm.position.x -= 0.002f;
    temp = get(leftArm);
    temp.components.push_back(forearm); //1
    update(leftArm, temp);

    pos = forearmPos; pos.z += 0.4f;
    Object hand = Object(pos, vec3(0), vec3(0), skinColor, GeometryCreator::CreateCube(vec3(0.1, 0.1, 0.2)), shaderVars);
    hand.rotationAngle = 15;
    hand.rotationAxis = vec3(1, 0, 0);
    temp = get(rightArm);
    temp.components.push_back(hand); //2
    update(rightArm, temp);

    hand.position.x -= 0.002f;
    temp = get(leftArm);
    temp.components.push_back(hand); //3
    update(leftArm, temp);

    //Zombies leg components
    pos = torsoPos; pos.y -= 0.5f;
    vec3 waistPos = pos; //Reference point to zombies waist position
    Object waist = Object(pos, vec3(0), vec3(0), jeansColor, GeometryCreator::CreateCylinder(0.22f, 0.22f, 0.2f, 32, 16), shaderVars);
    waist.rotationAngle = 90;
    waist.rotationAxis = vec3(1, 0, 0);
    Object::components.push_back(waist); //9

    pos = waistPos; pos.x -= 0.11f; pos.y -= 0.2f;
    Object thigh = Object(pos, vec3(0), vec3(0), jeansColor, GeometryCreator::CreateCylinder(0.1f, 0.12f, 0.3f, 32, 16), shaderVars);
    thigh.rotationAngle = 90;
    thigh.rotationAxis = vec3(1, 0, 0);
    Object::components.push_back(thigh); //10
    leftThigh = 10;

    thigh.position.x += 0.24f;
    Object::components.push_back(thigh); //11
    rightThigh = 11;

    pos = waistPos; pos.x -= 0.009f; pos.y += 0.8f; pos.z += 0.28f;
    vec3 legPos = pos;
    Object leg = Object(pos, vec3(0), vec3(0), jeansColor, GeometryCreator::CreateCylinder(0.12f, 0.1f, 0.3f, 32, 16), shaderVars);
    temp = get(leftThigh);
    temp.components.push_back(leg); //0
    update(leftThigh, temp);

    leg.position.x += 0.002f;
    temp = get(rightThigh);
    temp.components.push_back(leg); //1
    update(rightThigh, temp);

    pos = legPos; pos.z += 0.3f;
    legPos = pos;
    Object legBone = Object(pos, vec3(0), vec3(0), skinColor, GeometryCreator::CreateCylinder(0.05f, 0.05f, 0.2f, 32, 16), shaderVars);
    temp = get(leftThigh);
    temp.components.push_back(legBone); //2
    update(leftThigh, temp);

    legBone.position.x += 0.002f;
    temp = get(rightThigh);
    temp.components.push_back(legBone); //3
    update(rightThigh, temp);


    pos = legPos; pos.z += 0.2f;
    Object foot = Object(pos, vec3(0), vec3(0), vec3(0, 0, 0), GeometryCreator::CreateCube(vec3(0.2, 0.1, 0.3)), shaderVars);
    foot.rotationAngle = 90;
    foot.rotationAxis = vec3(1, 0, 0);
    temp = get(leftThigh);
    temp.components.push_back(foot); //4
    update(leftThigh, temp);

    foot.position.x += 0.002f;
    temp = get(rightThigh);
    temp.components.push_back(foot); //5
    update(rightThigh, temp);
}

Object Zombie::get(int index) {
    list<Object>::iterator i = Object::components.begin();
    advance(i, index);
    return *i;
}

Object Zombie::get(Object l, int index) {
    list<Object>::iterator i = l.components.begin();
    advance(i, index);
    return *i;
}

void Zombie::update(int index, Object o) {
    list<Object>::iterator i = Object::components.begin();
    advance(i, index);
    *i = o;
}

void Zombie::update(Object l, int index, Object o) {
    list<Object>::iterator i = l.components.begin();
    advance(i, index);
    *i = o;
}

void Zombie::animateWalk() {
    //Animate right leg
    Object temp = get(rightThigh);

    if(temp.rotationAngle == 100) {
        rightLegRot = -1 * ROTATE_AMOUNT;
    } else if(temp.rotationAngle == 60) {
        rightLegRot = ROTATE_AMOUNT;
    }

    temp.rotationAngle += rightLegRot;
    temp.rotationAxis = vec3(1, 0, 0);
    update(rightThigh, temp);

    //Animate left leg
    temp = get(leftThigh);

    if(temp.rotationAngle == 100) {
        leftLegRot = -1 * ROTATE_AMOUNT;
    } else if(temp.rotationAngle == 60) {
        leftLegRot = ROTATE_AMOUNT;
    }

    temp.rotationAngle += leftLegRot;
    temp.rotationAxis = vec3(1, 0, 0);
    update(leftThigh, temp);

    //Animate right arm
    temp = get(rightArm);

    if(temp.rotationAngle == 0) {
        rightArmRot = ROTATE_AMOUNT;
    } else if(temp.rotationAngle == 20) {
        rightArmRot = -1 * ROTATE_AMOUNT;
    }

    temp.rotationAngle += rightArmRot;
    temp.rotationAxis = vec3(1, 0, 0);
    update(rightArm, temp);

    //Animate left arm
    temp = get(leftArm);

    if(temp.rotationAngle == 0) {
        leftArmRot = ROTATE_AMOUNT;
    } else if(temp.rotationAngle == 20) {
        leftArmRot = -1 * ROTATE_AMOUNT;
    }

    temp.rotationAngle += leftArmRot;
    temp.rotationAxis = vec3(1, 0, 0);
    update(leftArm, temp);
}

void Zombie::lookTowards(vec3 camera) {
    vec2 from = vec2(position.x, position.z);
    vec2 to = vec2(camera.x, camera.z);

    float xDis = abs(from.x - to.x);
    float yDis = abs(from.y - to.y);

    float hypoth = sqrt((xDis * xDis) + (yDis * yDis));

    if(to.y - from.y < 0) {
        if(to.x - from.x > 0)
            rotationAngle = -1 * degrees(asin(xDis/hypoth)) - 180;
        else
            rotationAngle = degrees(asin(xDis/hypoth)) - 180;
    } else {
        if(to.x - from.x > 0)
            rotationAngle = degrees(asin(xDis/hypoth));
        else
            rotationAngle = -1 * degrees(asin(xDis/hypoth));

    }

    rotationAxis = vec3(0, 1, 0);
}

bool Zombie::isMoving(vec3 camera) {
    float dist = sqrt((position.x - camera.x) * (position.x - camera.x) +
            (position.z - camera.z) * (position.z - camera.z));

    if(dist < 40)
        return true;
    return false;
}

bool Zombie::attack(Camera *c) {
    float dist = sqrt((position.x - c->eye.x) * (position.x - c->eye.x) +
            (position.z - c->eye.z) * (position.z - c->eye.z));

    if(atk) {
        if(dist < ZOMBIE_REACH) { //Time for the beating
            cooldown++;
            if(cooldown > ZOMBIE_ATTACK_COOLDOWN) {
                cooldown = 0;
                cout << "health: " << c->health << endl;
                c->health -= ZOMBIE_DAMAGE;
                c->bleed();
                if(c->health <= 0) {
                    cout << "You have died" << endl;
                    c->fly = 1;
                    exit( EXIT_SUCCESS );
                }
            }
            return true;
        }
    } else {
       return true;
    }
    return false;
}
