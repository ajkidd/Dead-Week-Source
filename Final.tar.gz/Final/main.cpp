/*
 *  CPE 471 lab 4 - modern graphics test bed
 *  draws a partial cube using a VBO and IBO
 *  glut/OpenGL/GLSL application
 *  Uses glm and local matrix stack
 *  to handle matrix transforms for a view matrix, projection matrix and
 *  model transform matrix
 *
 *  zwood 9/12
 *  Copyright 2012 Cal Poly. All rights reserved.
 *
 *****************************************************************************/
#include "resources.h"
#include "Object.h"
#include "Bullet.h"
#include "Zombie.h"
#include "Building.h"
#include "Path.h"
#include "Camera.h"
#include "Map.h"
#include "CMeshLoaderSimple.h"

#define NUM_OBJECTS 20
#define SHOOT_COOL_DOWN 15
#define STREET 0
#define INTERSECTION 1
#define SIDEWALK 2

using namespace std;
using namespace glm;

//flag and ID to toggle on and off the shader
int shade = 1;
int cel;

//Handles to the shader data
GLint h_aPosition;
GLint h_aNormal;
GLint h_uColor;
GLint h_uModelMatrix;
GLint h_uViewMatrix;
GLint h_uProjMatrix;
GLint h_uView;

//Ground data
GLuint GrndBuffObj, GIndxBuffObj;
int g_GiboLen;

static const float g_groundY = 0.0;      // y coordinate of the ground
static const float g_groundSize = 200.0;   // half the ground length

/* globals to control positioning and window size */
static float g_width, g_height;

//declare a matrix stack
RenderingHelper ModelTrans;

//Meshes
Mesh *littleSphereMesh;
Mesh *sphereMesh;
Mesh *tallCylinderMesh;
Mesh *cylinderMesh;
Mesh *coneMesh;

//Step counter
int a_step = 0;

//World Material
list<Object> objects;
list<Bullet> bullets;
list<Building> buildings;
list<Path> streets, intersections, sidewalks;
list<Zombie> zombies;
Camera *camera;
Map *map;

//Expiration Lists
list<Object> expiredObjects;
list<Bullet> expiredBullets;
list<Zombie> expiredZombies;

// *** SHADERS *** //

/*function to help load the shaders (both vertex and fragment */
int InstallShader(const GLchar *vShaderName, const GLchar *fShaderName, int *shader) {
    GLuint VS; //handles to shader object
    GLuint FS; //handles to frag shader object
    GLint vCompiled, fCompiled, linked; //status of shader

    VS = glCreateShader(GL_VERTEX_SHADER);
    FS = glCreateShader(GL_FRAGMENT_SHADER);

    //load the source
    glShaderSource(VS, 1, &vShaderName, NULL);
    glShaderSource(FS, 1, &fShaderName, NULL);

    //compile shader and print log
    glCompileShader(VS);
    /* check shader status requires helper functions */
    printOpenGLError();
    glGetShaderiv(VS, GL_COMPILE_STATUS, &vCompiled);
    printShaderInfoLog(VS);

    //compile shader and print log
    glCompileShader(FS);
    /* check shader status requires helper functions */
    printOpenGLError();
    glGetShaderiv(FS, GL_COMPILE_STATUS, &fCompiled);
    printShaderInfoLog(FS);

    if (!vCompiled || !fCompiled) {
        printf("Error compiling either shader %s or %s", vShaderName, fShaderName);
        return 0;
    }

    //create a program object and attach the compiled shader
    cel = glCreateProgram();
    glAttachShader(*shader, VS);
    glAttachShader(*shader, FS);

    glLinkProgram(*shader);
    /* check shader status requires helper functions */
    printOpenGLError();
    glGetProgramiv(*shader, GL_LINK_STATUS, &linked);
    printProgramInfoLog(cel);

    glUseProgram(*shader);

    /* get handles to attribute data */
    h_aPosition = safe_glGetAttribLocation(*shader,      "aPosition");
    h_aNormal = safe_glGetAttribLocation(*shader,        "aNormal");
    h_uColor = safe_glGetUniformLocation(*shader,        "uColor");
    h_uProjMatrix = safe_glGetUniformLocation(*shader,   "uProjMatrix");
    h_uViewMatrix = safe_glGetUniformLocation(*shader,   "uViewMatrix");
    h_uModelMatrix = safe_glGetUniformLocation(*shader,  "uModelMatrix");
    h_uView = safe_glGetUniformLocation(*shader,         "uView");

    printf("sucessfully installed shader %d\n", *shader);
    return 1;
}

/* intialize ground data */
//*Unused atm
static void initGround() {

    // A x-z plane at y = g_groundY of dimension [-g_groundSize, g_groundSize]^2
    float GrndPos[] = {
        -g_groundSize, g_groundY, -g_groundSize,
        -g_groundSize, g_groundY,  g_groundSize,
        g_groundSize, g_groundY,  g_groundSize,
        g_groundSize, g_groundY, -g_groundSize
    };
    unsigned short idx[] = {0, 1, 2, 0, 2, 3};

    g_GiboLen = 6;
    glGenBuffers(1, &GrndBuffObj);
    glBindBuffer(GL_ARRAY_BUFFER, GrndBuffObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GrndPos), GrndPos, GL_STATIC_DRAW);

    glGenBuffers(1, &GIndxBuffObj);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, GIndxBuffObj);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);
}

// *** DRAWING TO SCREEN *** //

void drawObject(Object o) {
    ModelTrans.loadIdentity();
    o.Draw(&ModelTrans);
}

/* projection matrix - do not change - sets matrix in shader */
void SetProjectionMatrix() {
    glm::mat4 Projection = glm::perspective(80.0f, (float)g_width/g_height, 0.1f, 100.f);
    safe_glUniformMatrix4fv(h_uProjMatrix, glm::value_ptr(Projection));
}

/* camera controls - do not change - sets matrix in shader */
void SetView() {
    mat4 camMat = lookAt(camera->eye, camera->lookAt, camera->up);
    safe_glUniformMatrix4fv(h_uViewMatrix, value_ptr(camMat));
}

/* model transforms - do not change - sets matrix in shader */
void SetModel() {
    safe_glUniformMatrix4fv(h_uModelMatrix, glm::value_ptr(ModelTrans.modelViewMatrix));
}

/* Glut Draw function */
void Draw (void)
{

    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //Start our shader
    glUseProgram(cel);

    /* only set the projection and view matrix once */
    SetProjectionMatrix();
    SetView();


    /******************* set up to draw the ground plane */
    /*safe_glEnableVertexAttribArray(h_aPosition);
    // bind vbo
    glBindBuffer(GL_ARRAY_BUFFER, GrndBuffObj);
    safe_glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);
    // bind ibo
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, GIndxBuffObj);
     */


    /* set the color in the shader */
    glUniform3f(h_uView, camera->eye.x - camera->lookAt.x, camera->eye.y - camera->lookAt.y, camera->eye.z - camera->lookAt.z);

    glUniform3f(h_uColor, 0.3, 0.62, 0.33);

    /* set the matrix stack to the identity - no transforms on the ground*/
    ModelTrans.loadIdentity();
    SetModel();
    // draw!
    glDrawElements(GL_TRIANGLES, g_GiboLen, GL_UNSIGNED_SHORT, 0);

    // Disable the attributes used by our shader
    safe_glDisableVertexAttribArray(h_aPosition);

    drawObject(*(camera->object));
    for (list<Object>::iterator it = objects.begin(); it != objects.end(); it++) {
        drawObject(*it);
    }
    for (list<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++) {
        drawObject((Object)*it);
    }
    for (list<Zombie>::iterator it = map->zombies.begin(); it != map->zombies.end(); it++) {
        drawObject((Object)*it);
    }
    for(list<Object>::iterator it = map->buildings.begin(); it != map->buildings.end(); it++) {
        drawObject(*it);
    }
    for(list<Path>::iterator it = map->streets.begin(); it != map->streets.end(); it++) {
        drawObject((Object)*it);
    }
    for(list<Path>::iterator it = map->sidewalks.begin(); it != map->sidewalks.end(); it++) {
        drawObject((Object)*it);
    }
    for(list<Path>::iterator it = map->intersections.begin(); it != map->intersections.end(); it++) {
        drawObject((Object)*it);
    }
    for(list<Monument>::iterator it = map->monuments.begin(); it != map->monuments.end(); it++) {
        drawObject((Object)*it);
    }

    // Disable the attributes used by our shader
    safe_glDisableVertexAttribArray(h_aPosition);

    //Disable the shader
    glUseProgram(0);
    glutSwapBuffers();

}

/* Window Reshape */
void ReshapeGL (int width, int height)
{
    g_width = (float)width;
    g_height = (float)height;
    camera->screen(g_width, g_height);
    glViewport (0, 0, (GLsizei)(width), (GLsizei)(height));

}

// *** KEYBOARD HANDLERS *** //

bool keys[256];

//the step keyboard call
void keyboardActions() {

    if (keys['a']) {
        camera->moveLeft(&(map->buildings));
    }
    if (keys['d']) {
        camera->moveRight(&(map->buildings));
    }
    if (keys['w']) {
        camera->moveForward(&(map->buildings));
    }
    if (keys['s']) {
        camera->moveBack(&(map->buildings));
    }
    if (keys['f']) {
        camera->fly = !(camera->fly);
        camera->groundEyes();
    }
    if (keys['p'] || keys['P']) {
        exit( EXIT_SUCCESS );
    }

    glutPostRedisplay();
}

void keyboardKeyDown(unsigned char key, int x, int y) {
    keys[key] = true;
}

void keyboardKeyUp(unsigned char key, int x, int y) {
    keys[key] = false;
}

// *** MOUSE HANDLERS *** //

bool firstMouseMove = true;
bool userMouseMove = true;
bool leftMouseDown = false;
bool rightMouseDown = false;

void mouseClicked(int button, int state, int x, int y) {

    camera->cur.x = x;
    camera->cur.y = y;

    if(state == GLUT_DOWN) {
        if(button == GLUT_LEFT_BUTTON) {
            leftMouseDown = true;
        } else if (button == GLUT_RIGHT_BUTTON) {
            rightMouseDown = true;
        }
    } else {
        if(button == GLUT_LEFT_BUTTON) {
            leftMouseDown = false;
        } else if (button == GLUT_RIGHT_BUTTON) {
            rightMouseDown = false;
        }
    }

}

//*Unused
void mouseMove(int x, int y) {
    if (userMouseMove) {
        camera->prev.x = g_width / 2;
        camera->prev.y = g_height / 2;
        camera->cur.x = x;
        camera->cur.y = y;
        camera->mouseMove();

        glutPostRedisplay();
        userMouseMove = false;
        glutWarpPointer(g_width / 2, g_height / 2);
    } else {
        userMouseMove = true;
    }
    glutPostRedisplay();
}

void mousePassiveMove(int x, int y) {
    if (userMouseMove) {
        userMouseMove = false;
        if (firstMouseMove) {
            firstMouseMove = false;
        } else {
            camera->prev.x = g_width / 2;
            camera->prev.y = g_height / 2;
            camera->cur.x = x;
            camera->cur.y = y;
            camera->mouseMove();
        }
        glutPostRedisplay();
        glutWarpPointer(g_width / 2, g_height / 2);
    } else {
        userMouseMove = true;
    }
    glutPostRedisplay();
}

// *** MAIN LOOP *** //

//*Unused
void animationLoop(int none) {
    glutTimerFunc(1000.0 / 60.0, animationLoop, none);
    a_step++;
    glutPostRedisplay();
}

int shootCoolDown = 0;

void shoot() {
    GLint shaderVars[4] = {
        h_uModelMatrix, h_aPosition, h_aNormal, h_uColor
    };
    bullets.push_back(Bullet(camera->eye, camera->eye - camera->lookAt, vec3( (rand() % 100) / 100.0, (rand() % 100) / 100.0, (rand() % 100) / 100.0),
                sphereMesh, shaderVars));
    shootCoolDown = SHOOT_COOL_DOWN;
}

bool isExpired(const Object& value) {
    return value.expired;
}

void objectCleanup() {
    int less = map->zombies.size();
    objects.remove_if(isExpired);
    bullets.remove_if(isExpired);
    map->zombies.remove_if(isExpired);
    less -= map->zombies.size();
    map->numZombies -= less;
}

void step(int none) {
    glutTimerFunc(1000.0 / 60.0, step, none);
    a_step++;
    if (!shootCoolDown && leftMouseDown) {
        shoot();
    } else if (shootCoolDown > 0) {
        shootCoolDown--;
    }
    for (list<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++) {
        it->move();
        for (list<Zombie>::iterator ob = map->zombies.begin(); ob != map->zombies.end(); ob++) {
            it->hits(&(*ob));
        }
        for(list<Object>::iterator ob = map->buildings.begin(); ob != map->buildings.end(); ob++) {
            it->hits((Object*)(&(*ob)));
        }
        for(list<Path>::iterator ob = map->streets.begin(); ob != map->streets.end(); ob++) {
            it->hits((Object*)(&(*ob)));
        }
        for(list<Path>::iterator ob = map->sidewalks.begin(); ob != map->sidewalks.end(); ob++) {
            it->hits((Object*)(&(*ob)));
        }
        for(list<Path>::iterator ob = map->intersections.begin(); ob != map->intersections.end(); ob++) {
            it->hits((Object*)(&(*ob)));
        }
    }
    for (list<Zombie>::iterator it = map->zombies.begin(); it != map->zombies.end(); it++) {
        if(it->isMoving(camera->eye)) {
            if (!(it->attack(camera))) {
               it->moveToward(camera->eye, &(map->buildings));
            }
            glClearColor(camera->blood.r, camera->blood.g, camera->blood.b, 0);
            it->animateWalk();
            it->lookTowards(camera->eye);
        }
    }
    for (list<Monument>::iterator it = map->monuments.begin(); it != map->monuments.end(); it++) {
        it->animate(camera);
    }

    //Respawn
    map->respawnCount++;
    if(map->respawnCount > 60*5) {
        map->respawnCount = 0;
        map->respawn();
    }
    keyboardActions();

    objectCleanup();
    glutPostRedisplay();
}

/* Some OpenGL initialization */
void Initialize ()
{
    // Start Of User Initialization
    glClearColor (0, .2, .2, 0);
    // Black Background
    glClearDepth (1.0f);    // Depth Buffer Setup
    glDepthFunc (GL_LEQUAL);    // The Type Of Depth Testing
    glEnable (GL_DEPTH_TEST);// Enable Depth Testing

    /* some matrix stack init */
    ModelTrans.useModelViewMatrix();
}

int main( int argc, char *argv[] )
{
    glutInit( &argc, argv );
    glutInitWindowPosition( 20, 20 );
    glutInitWindowSize( 800, 600 );
    glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
    glutCreateWindow("Cube and Transforms");
    glutReshapeFunc( ReshapeGL );
    glutDisplayFunc( Draw );
    glutKeyboardFunc( keyboardKeyDown );
    glutKeyboardUpFunc( keyboardKeyUp );
    glutMouseFunc( mouseClicked );
    glutMotionFunc( mouseMove );
    glutPassiveMotionFunc( mousePassiveMove );
    glutFullScreen();
    glutWarpPointer(g_width / 2, g_height / 2);
    glutSetCursor(GLUT_CURSOR_CROSSHAIR);
    Initialize();

    //test the openGL version
    getGLversion();
    //install the shader
    if (!InstallShader(textFileRead((char *)"CellShading.vert"), textFileRead((char *)"CellShading.frag"), &cel)) {
        printf("Error installing shader!\n");
        return 0;
    }

    //*Unused - For the smooth shading
    /*if (!InstallShader(textFileRead((char *)"vert.glsl"), textFileRead((char *)"frag.glsl"))) {
      printf("Error installing shader!\n");
      return 0;
      }*/

    sphereMesh = GeometryCreator::ReadMesh("Models/bunny.orig.m");
    //sphereMesh = GeometryCreator::CreateSphere(glm::vec3(.3f));
    littleSphereMesh = GeometryCreator::CreateSphere(glm::vec3(0.5f));
    cylinderMesh = GeometryCreator::CreateCylinder(0.2f, 0.15f, 0.3f, 32, 16);
    tallCylinderMesh = GeometryCreator::CreateCylinder(1.0f, 1.0f, 5.0f, 32, 16);
    coneMesh = GeometryCreator::CreateCylinder(2.0f, 0.0f, 5.0f, 32, 16);

    GLint shaderVars[4] = {h_uModelMatrix, h_aPosition, h_aNormal, h_uColor};
    map = new Map(argv[1], shaderVars);
    camera = new Camera(map->cameraPos, map->cameraLookAt, vec3(0, 1, 0), 0.2, g_width, g_height, shaderVars);

    //Initialize stuff
    initGround();

    glutTimerFunc(1000.0 / 60.0, step, 0);
    glutMainLoop();
    return 0;
}
