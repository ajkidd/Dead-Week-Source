#include "Monument.h"

Monument::Monument(char *file, vec3 pos, GLint *shaderVars) : Object(pos, vec3(-1.5, -3, -1.5), vec3(1.5, 3, 1.5), vec3(0.5), GeometryCreator::CreateCube(vec3(3, 6, 3)), shaderVars) {
    buildMonument(file);
    scaleBy = 0.02;
    cur = 0; prev = 0;
    cooldown = 0;
}

void Monument::buildMonument(char *file) {
    GLint shaderVars[4] = { h_uModelMatrix, h_aPosition, h_aNormal, h_uColor };
    vec3 pos = vec3(0, 4.5, 0);
    vec3 ref = pos; //Reference point to buildings position
    vec3 color = Object::color;
    
    if (!strlen(file)) {
        Object mesh = Object(pos, vec3(0), vec3(0), vec3(1, 0, 0), GeometryCreator::CreateSphere(vec3(0)), shaderVars);
    } else {
        Object mesh = Object(pos, vec3(0), vec3(0), vec3(1, 0, 0), GeometryCreator::ReadMesh(file), shaderVars);
       mesh.scale = vec3(4);
       Object::components.push_back(mesh); //0

       Object torus = Object(pos, vec3(0), vec3(0), vec3(1, 0, 0), GeometryCreator::CreateTorus(2, 3, 32, 16), shaderVars);
       torus.rotationAngle = 90;
       torus.rotationAxis = vec3(1, 0, 0);
       Object::components.push_back(torus); //1
    }
}

void Monument::animate(Camera *c) {
    dist(c);
    Object t = get(1);

    if(t.scale.x > 3) {
        t.scale = vec3(1);
    }

    t.scale.x += scaleBy;
    t.scale.y += scaleBy;
    update(1, t);
}

void Monument::dist(Camera *c) {
    prev = cur;

    if(prev == 0 && cur == 0) {
        cur = sqrt((position.x - c->eye.x) * (position.x - c->eye.x) +
                (position.z - c->eye.z) * (position.z - c->eye.z));
        return;
    }

    cur = sqrt((position.x - c->eye.x) * (position.x - c->eye.x) +
            (position.z - c->eye.z) * (position.z - c->eye.z));

    if(cur < prev && cur < DIST) { //increase green
        Object m = get(0);
        if(m.color.r > 0)
            m.color.r -= COLOR_INCREMENT;
        if(m.color.g < 1)
            m.color.g += COLOR_INCREMENT;
        update(0, m);

        Object t = get(1);
        if(t.color.r > 0)
            t.color.r -= COLOR_INCREMENT;
        if(t.color.g < 1)
            t.color.g += COLOR_INCREMENT;
        update(1, t);

        if(t.color.g > 0.9) {
            cooldown++;
            if(cooldown > 10) {
                cooldown = 0;
                c->health += 10;
                if(c->health > 100) {
                    c->health = 100;
                    //c->blood = vec3(0.53, 1, 1);
                }
                c->heal();
            }
        }

    } else if(cur > prev && cur < DIST) { //increase red
        Object m = get(0);
        if(m.color.g > 0)
            m.color.g -= COLOR_INCREMENT;
        if(m.color.r < 1)
            m.color.r += COLOR_INCREMENT;
        update(0, m);

        Object t = get(1);
        if(t.color.g > 0)
            t.color.g -= COLOR_INCREMENT;
        if(t.color.r < 1)
            t.color.r += COLOR_INCREMENT;
        update(1, t);

        if(t.color.g > 0.9) {
            cooldown++;
            if(cooldown > HEAL_COOLDOWN) {
                cooldown = 0;
                c->health += HEALING;
                if(c->health > 100) {
                    c->health = 100;
                    //c->blood = vec3(0.53, 1, 1);
                }
                c->heal();
            }
        }
    }
}

Object Monument::get(int index) {
    list<Object>::iterator i = Object::components.begin();
    advance(i, index);
    return *i;
}

void Monument::update(int index, Object o) {
    list<Object>::iterator i = Object::components.begin();
    advance(i, index);
    *i = o;
}
