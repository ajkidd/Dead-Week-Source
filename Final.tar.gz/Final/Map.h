#ifndef __MAP__
#define __MAP__

#include <fstream>
#include "resources.h"
#include "Building.h"
#include "Path.h"
#include "Zombie.h"
#include "Monument.h"

#define NUM_OF_ZOMBIES 50
#define RESPAWN_ZOMBIES 5
#define MAX_ZOMBIES 60
#define CHARS_PER_LINE 500
#define STREET 0
#define INTERSECTION 1
#define SIDEWALK 2
#define WALL 0

using namespace std;
using namespace glm;

class Map {
    private:
	GLint *shaderVars;
        int count;
        char *file;

    public:
        vec3 cameraPos;
        vec3 cameraLookAt;
        list<Zombie> zombies;
        list<Object> buildings;
        list<Path> streets, intersections, sidewalks;
        list<Monument> monuments;
        int probability;
        int respawnCount;
        int numZombies;

    private:
        void initWorld(char *file);

    public:
        Map(char *file, GLint *shaderVars);
        void respawn();
};

#endif
